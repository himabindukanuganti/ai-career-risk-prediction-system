from fastapi import APIRouter
from pydantic import BaseModel
from typing import List, Optional
import os, sys
sys.path.insert(0, os.path.dirname(os.path.dirname(__file__)))
from ml.risk_model import predict_career_risk

router = APIRouter()

class SkillItem(BaseModel):
    name: str; level: str = "Intermediate"; score: float = 0.5; category: str = ""

class RiskReq(BaseModel):
    role: str; years_exp: float; skills: List[SkillItem]
    education_level: float = 0.5; market_data: Optional[dict] = None

@router.post("/predict")
def predict(req: RiskReq):
    r = predict_career_risk(req.role, req.years_exp, [s.dict() for s in req.skills],
                            req.education_level, req.market_data)
    return {"role":r.role,"risk_score":r.risk_score,"risk_category":r.risk_category,
            "viability_index":r.viability_index,"shap_values":r.shap_values}

@router.get("/automation-index/{role}")
def auto_index(role: str):
    from ml.risk_model import OCCUPATION_AUTO_INDEX
    d = OCCUPATION_AUTO_INDEX.get(role.lower())
    if not d: return {"error":"role not found"}
    return {"role":role,**d}
