from fastapi import FastAPI
from fastapi.middleware.cors import CORSMiddleware
from dotenv import load_dotenv
import os

load_dotenv()

from routes import resume, skills, risk, trends, recommendations
from data.websocket import router as ws_router
from data.scheduler import start_scheduler

app = FastAPI(
    title="AI Career Risk & Job Trend Prediction System",
    version="1.0.0"
)

app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_methods=["*"],
    allow_headers=["*"],
)

app.include_router(resume.router,         prefix="/api/v1/resume",      tags=["Resume Parser"])
app.include_router(skills.router,          prefix="/api/v1/skills",       tags=["Skill Extraction"])
app.include_router(risk.router,            prefix="/api/v1/risk",         tags=["Risk Prediction"])
app.include_router(trends.router,          prefix="/api/v1/trends",       tags=["Job Trends"])
app.include_router(recommendations.router, prefix="/api/v1/recommend",    tags=["Recommendations"])
app.include_router(ws_router,              prefix="/ws",                  tags=["WebSocket"])

@app.on_event("startup")
async def startup():
    start_scheduler()

@app.get("/")
def root():
    return {"message": "CareerAI API running", "docs": "/docs"}

@app.get("/health")
def health():
    return {"status": "healthy"}
