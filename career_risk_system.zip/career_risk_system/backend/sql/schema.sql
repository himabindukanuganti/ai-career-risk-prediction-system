"""
migrations/schema.sql — PostgreSQL schema for Phase 3

Run with:
  psql $DATABASE_URL -f migrations/schema.sql

Or use Alembic:
  alembic upgrade head
"""

-- ── Extensions ────────────────────────────────────────────────────────────────
CREATE EXTENSION IF NOT EXISTS "uuid-ossp";
CREATE EXTENSION IF NOT EXISTS "pg_trgm";   -- for fast skill text search

-- ── Users ─────────────────────────────────────────────────────────────────────
CREATE TABLE IF NOT EXISTS users (
    id           INTEGER PRIMARY KEY AUTOINCREMENT,
    name         TEXT        NOT NULL,
    email        TEXT        UNIQUE NOT NULL,
    password     TEXT        NOT NULL,
    role         TEXT        NOT NULL DEFAULT 'user',
    is_active    BOOLEAN     NOT NULL DEFAULT TRUE,
    created_at   TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    last_login   TIMESTAMPTZ
);
CREATE INDEX IF NOT EXISTS idx_users_email ON users (email);

-- ── Refresh tokens ────────────────────────────────────────────────────────────
CREATE TABLE IF NOT EXISTS refresh_tokens (
    id         INTEGER PRIMARY KEY AUTOINCREMENT,
    user_id    INTEGER     NOT NULL REFERENCES users(id) ON DELETE CASCADE,
    token      TEXT        UNIQUE NOT NULL,
    expires_at TIMESTAMPTZ NOT NULL,
    revoked    BOOLEAN     NOT NULL DEFAULT FALSE,
    created_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);
CREATE INDEX IF NOT EXISTS idx_rt_token   ON refresh_tokens (token);
CREATE INDEX IF NOT EXISTS idx_rt_user    ON refresh_tokens (user_id);

-- ── Password reset tokens ─────────────────────────────────────────────────────
CREATE TABLE IF NOT EXISTS pw_reset_tokens (
    id         INTEGER PRIMARY KEY AUTOINCREMENT,
    user_id    INTEGER     NOT NULL REFERENCES users(id) ON DELETE CASCADE,
    token      TEXT        UNIQUE NOT NULL,
    expires_at TIMESTAMPTZ NOT NULL,
    used       BOOLEAN     NOT NULL DEFAULT FALSE
);

-- ── User profiles ─────────────────────────────────────────────────────────────
CREATE TABLE IF NOT EXISTS user_profiles (
    id              INTEGER PRIMARY KEY AUTOINCREMENT,
    user_id         INTEGER     UNIQUE NOT NULL REFERENCES users(id) ON DELETE CASCADE,
    current_role    TEXT,
    target_role     TEXT,
    years_exp       REAL        NOT NULL DEFAULT 0,
    education_level REAL        NOT NULL DEFAULT 0.5,
    skills          JSONB       NOT NULL DEFAULT '[]',
    updated_at      TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

-- ── Saved analyses ────────────────────────────────────────────────────────────
CREATE TABLE IF NOT EXISTS saved_analyses (
    id         INTEGER PRIMARY KEY AUTOINCREMENT,
    user_id    INTEGER     NOT NULL REFERENCES users(id) ON DELETE CASCADE,
    type       TEXT        NOT NULL CHECK (type IN ('resume','risk','trend','roadmap')),
    title      TEXT        NOT NULL,
    data       JSONB       NOT NULL DEFAULT '{}',
    created_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);
CREATE INDEX IF NOT EXISTS idx_sa_user_type ON saved_analyses (user_id, type);

-- ── API cache ─────────────────────────────────────────────────────────────────
CREATE TABLE IF NOT EXISTS api_cache (
    key        TEXT        PRIMARY KEY,
    value      JSONB       NOT NULL,
    fetched_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

-- ── Job trends (time-series) ──────────────────────────────────────────────────
CREATE TABLE IF NOT EXISTS job_trends (
    id             INTEGER PRIMARY KEY AUTOINCREMENT,
    role           TEXT        NOT NULL,
    date           DATE        NOT NULL,
    posting_count  INTEGER     NOT NULL,
    avg_salary     REAL,
    source         TEXT,
    fetched_at     TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    UNIQUE (role, date, source)
);
CREATE INDEX IF NOT EXISTS idx_jt_role_date ON job_trends (role, date DESC);

-- ── ML model registry ─────────────────────────────────────────────────────────
CREATE TABLE IF NOT EXISTS model_registry (
    id           INTEGER PRIMARY KEY AUTOINCREMENT,
    name         TEXT        NOT NULL,
    version      TEXT        NOT NULL,
    algorithm    TEXT        NOT NULL,
    artifact_path TEXT       NOT NULL,
    metrics      JSONB       NOT NULL DEFAULT '{}',
    params       JSONB       NOT NULL DEFAULT '{}',
    trained_at   TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    is_active    BOOLEAN     NOT NULL DEFAULT TRUE,
    UNIQUE (name, version)
);

-- ── Admin audit log ───────────────────────────────────────────────────────────
CREATE TABLE IF NOT EXISTS audit_log (
    id         INTEGER PRIMARY KEY AUTOINCREMENT,
    user_id    INTEGER     REFERENCES users(id) ON DELETE SET NULL,
    action     TEXT        NOT NULL,
    resource   TEXT,
    detail     JSONB       NOT NULL DEFAULT '{}',
    created_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);
CREATE INDEX IF NOT EXISTS idx_audit_user ON audit_log (user_id);
CREATE INDEX IF NOT EXISTS idx_audit_time ON audit_log (created_at DESC);
