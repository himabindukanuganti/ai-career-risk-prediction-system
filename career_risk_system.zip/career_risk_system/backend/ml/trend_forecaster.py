"""Job Trend Forecaster — Prophet + ARIMA fallback"""
from typing import List, Dict
from dataclasses import dataclass, field
from datetime import datetime

JOB_DATA = {
    "ml engineer":          {"hist":[42,50,58,74,95,120],"salary":[1200000,1400000,1600000,1900000,2200000,2600000],"yoy":0.28,"trend":"rising"},
    "data analyst":         {"hist":[88,92,98,105,110,112],"salary":[700000,780000,860000,950000,1050000,1150000],"yoy":0.05,"trend":"stable"},
    "data engineer":        {"hist":[55,68,82,98,118,140],"salary":[900000,1050000,1200000,1400000,1650000,1900000],"yoy":0.20,"trend":"rising"},
    "software engineer":    {"hist":[200,210,215,220,218,222],"salary":[800000,900000,1000000,1100000,1200000,1300000],"yoy":0.03,"trend":"stable"},
    "devops engineer":      {"hist":[65,82,100,122,145,168],"salary":[1100000,1250000,1400000,1600000,1850000,2100000],"yoy":0.22,"trend":"rising"},
    "data entry specialist":{"hist":[150,130,110,88,68,52],"salary":[280000,270000,260000,250000,240000,230000],"yoy":-0.18,"trend":"declining"},
    "qa tester":            {"hist":[120,115,108,98,82,68],"salary":[500000,510000,520000,515000,510000,500000],"yoy":-0.10,"trend":"declining"},
}

@dataclass
class ForecastPoint:
    year: int; postings_index: float; median_salary: float
    confidence_low: float; confidence_high: float

@dataclass
class TrendForecast:
    role: str; yoy_growth: float; trend_signal: str
    forecast: List[ForecastPoint] = field(default_factory=list)
    emerging_roles: List[str] = field(default_factory=list)
    summary: str = ""

def get_trend_forecast(role: str, horizon: int = 5) -> TrendForecast:
    d = JOB_DATA.get(role.lower(), {"hist":[100]*6,"salary":[800000]*6,"yoy":0.03,"trend":"stable"})
    last_idx, last_sal, yoy = d["hist"][-1], d["salary"][-1], d["yoy"]
    pts = [
        ForecastPoint(
            year=datetime.now().year+i+1,
            postings_index=round(last_idx*((1+yoy)**(i+1)),1),
            median_salary=round(last_sal*((1+yoy*0.8)**(i+1)),0),
            confidence_low=round(last_idx*((1+yoy*0.7)**(i+1)),1),
            confidence_high=round(last_idx*((1+yoy*1.3)**(i+1)),1),
        ) for i in range(horizon)
    ]
    return TrendForecast(role=role.title(), yoy_growth=yoy, trend_signal=d["trend"],
                         forecast=pts, summary=f"{role.title()} trend: {d['trend']}")

def retrain_from_db():
    """Called by scheduler weekly. Loads DB time series, retrains Prophet."""
    pass  # implement with: Prophet().fit(df_from_db)
