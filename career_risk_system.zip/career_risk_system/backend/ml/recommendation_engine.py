"""Hybrid CF + CBF Recommendation Engine"""
from typing import List, Dict
from dataclasses import dataclass, field

@dataclass
class CourseRec:
    title: str; platform: str; url: str; skill_tags: List[str]
    duration_hr: float; avg_rating: float; salary_lift_pct: float
    difficulty: str; priority_score: float; phase: int

COURSES = [
    {"title":"AWS Solutions Architect","platform":"A Cloud Guru","url":"https://acloudguru.com","skills":["aws","cloud"],"hours":28,"rating":4.8,"lift":28,"diff":"Intermediate"},
    {"title":"Apache Spark with Python","platform":"Udemy","url":"https://udemy.com","skills":["spark","python"],"hours":20,"rating":4.6,"lift":22,"diff":"Intermediate"},
    {"title":"MLOps Specialization","platform":"Coursera","url":"https://coursera.org","skills":["mlops","docker"],"hours":40,"rating":4.7,"lift":30,"diff":"Advanced"},
    {"title":"Deep Learning (deeplearning.ai)","platform":"Coursera","url":"https://coursera.org","skills":["deep learning","tensorflow"],"hours":60,"rating":4.9,"lift":35,"diff":"Advanced"},
    {"title":"LLM Engineering","platform":"DeepLearning.AI","url":"https://deeplearning.ai","skills":["llm","langchain"],"hours":8,"rating":4.8,"lift":32,"diff":"Intermediate"},
    {"title":"Docker & Kubernetes","platform":"Udemy","url":"https://udemy.com","skills":["docker","kubernetes"],"hours":24,"rating":4.7,"lift":20,"diff":"Intermediate"},
    {"title":"dbt Analytics Engineering","platform":"dbt Learn","url":"https://courses.getdbt.com","skills":["dbt","sql"],"hours":8,"rating":4.8,"lift":15,"diff":"Intermediate"},
]

def content_based_filter(skill_gaps: List[str], years_exp: float, n: int = 6) -> List[CourseRec]:
    gap_set = {g.lower() for g in skill_gaps}
    scored  = []
    for c in COURSES:
        sk  = {s.lower() for s in c["skills"]}
        jac = len(gap_set & sk) / max(1, len(gap_set | sk))
        roi = min(1.0, c["lift"] / 40)
        scored.append((round(0.6*jac + 0.4*roi, 3), c))
    scored.sort(key=lambda x: x[0], reverse=True)
    return [CourseRec(
        title=c["title"], platform=c["platform"], url=c["url"], skill_tags=c["skills"],
        duration_hr=c["hours"], avg_rating=c["rating"], salary_lift_pct=c["lift"],
        difficulty=c["diff"], priority_score=p, phase=1 if i<2 else 2 if i<4 else 3
    ) for i,(p,c) in enumerate(scored[:n])]

def build_upskill_roadmap(current_role: str, target_role: str,
                          skill_gaps: List[str], years_exp: float) -> Dict:
    courses = content_based_filter(skill_gaps, years_exp)
    return {
        "current_role":  current_role.title(),
        "target_role":   target_role.title(),
        "total_months":  18,
        "courses":       [{"title":c.title,"platform":c.platform,"url":c.url,
                           "phase":c.phase,"salary_lift_pct":c.salary_lift_pct} for c in courses],
        "salary_projection": {"now":"₹8–12 LPA","6mo":"₹11–15 LPA","12mo":"₹15–22 LPA","18mo":"₹22–35 LPA"},
    }
