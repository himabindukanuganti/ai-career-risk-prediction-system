import os
import json
import pickle
import logging
from pathlib import Path
from datetime import datetime, timezone
from typing import Dict, List, Optional, Tuple

try:
    import numpy as np
    import pandas as pd
    HAS_NUMPY = True
except ImportError:
    HAS_NUMPY = False
    import logging; logging.getLogger(__name__).warning("numpy/pandas not installed — XGBoost model unavailable")

logger = logging.getLogger(__name__)

MODEL_DIR  = Path(__file__).parent.parent / "models"
MODEL_PATH = MODEL_DIR / "risk_model.pkl"
META_PATH  = MODEL_DIR / "risk_model_meta.json"
MODEL_DIR.mkdir(exist_ok=True)

# ── Feature names (must match training order) ─────────────────────────────────
FEATURES = [
    "routine_task_ratio",     # from O*NET task importance scores
    "ai_replaceability",      # from Felten et al. LLM exposure mapping
    "sector_automation",      # from McKinsey sector automation estimates
    "skill_uniqueness",       # n_skills / 20 (capped at 1.0)
    "education_level",        # 0.25=diploma 0.5=bachelor 0.75=master 1.0=phd
    "experience_years_norm",  # years / 20 (capped at 1.0)
    "demand_growth",          # YoY job posting growth rate
    "remote_work_ratio",      # remote postings / total postings
]

# ── Training data — O*NET grounded occupational profiles ─────────────────────
# Each row: [routine, ai_replace, sector_auto, skill_uniq, edu, exp_norm,
#            demand_growth, remote_ratio, risk_label (0-3)]
# Labels: 0=Low, 1=Medium, 2=High, 3=Critical
TRAINING_DATA = [
    # Critical risk roles (3)
    [0.92, 0.94, 0.88, 0.10, 0.25, 0.20,  -0.18, 0.05, 3],  # data entry
    [0.88, 0.86, 0.82, 0.12, 0.25, 0.15,  -0.22, 0.03, 3],  # cashier
    [0.85, 0.90, 0.80, 0.08, 0.30, 0.25,  -0.15, 0.04, 3],  # telemarketer
    [0.87, 0.88, 0.84, 0.09, 0.25, 0.18,  -0.20, 0.06, 3],  # loan officer (routine)
    [0.84, 0.85, 0.79, 0.11, 0.35, 0.22,  -0.12, 0.07, 3],  # bookkeeping clerk
    [0.89, 0.91, 0.85, 0.07, 0.20, 0.10,  -0.25, 0.02, 3],  # assembly line worker
    [0.83, 0.87, 0.81, 0.10, 0.28, 0.20,  -0.14, 0.05, 3],  # toll booth operator

    # High risk roles (2)
    [0.72, 0.68, 0.62, 0.20, 0.35, 0.30,  -0.10, 0.10, 2],  # qa tester
    [0.68, 0.72, 0.58, 0.22, 0.40, 0.35,  -0.08, 0.12, 2],  # customer support
    [0.78, 0.70, 0.65, 0.15, 0.50, 0.40,  -0.05, 0.15, 2],  # accountant
    [0.70, 0.65, 0.60, 0.25, 0.50, 0.45,  -0.07, 0.18, 2],  # paralegal
    [0.75, 0.72, 0.68, 0.18, 0.45, 0.38,  -0.09, 0.14, 2],  # radiologist (routine tasks)
    [0.65, 0.78, 0.62, 0.20, 0.50, 0.42,  -0.06, 0.20, 2],  # financial analyst (basic)
    [0.73, 0.69, 0.64, 0.17, 0.40, 0.35,  -0.11, 0.11, 2],  # insurance underwriter

    # Medium risk roles (1)
    [0.45, 0.42, 0.38, 0.40, 0.50, 0.40,   0.05, 0.25, 1],  # data analyst
    [0.35, 0.38, 0.40, 0.50, 0.50, 0.45,   0.03, 0.30, 1],  # software engineer
    [0.40, 0.35, 0.42, 0.45, 0.55, 0.50,   0.08, 0.35, 1],  # product manager
    [0.38, 0.40, 0.36, 0.48, 0.60, 0.55,   0.06, 0.40, 1],  # business analyst
    [0.42, 0.45, 0.39, 0.42, 0.50, 0.48,   0.04, 0.28, 1],  # marketing specialist
    [0.35, 0.42, 0.38, 0.50, 0.55, 0.52,   0.07, 0.32, 1],  # project manager
    [0.48, 0.44, 0.40, 0.38, 0.50, 0.42,   0.02, 0.22, 1],  # operations manager

    # Low risk roles (0)
    [0.20, 0.15, 0.30, 0.75, 0.75, 0.70,   0.28, 0.70, 0],  # ml engineer
    [0.30, 0.28, 0.35, 0.65, 0.65, 0.60,   0.20, 0.65, 0],  # data engineer
    [0.25, 0.22, 0.32, 0.70, 0.70, 0.65,   0.22, 0.72, 0],  # devops engineer
    [0.18, 0.20, 0.28, 0.80, 0.80, 0.75,   0.30, 0.75, 0],  # ai researcher
    [0.22, 0.18, 0.30, 0.78, 0.75, 0.72,   0.25, 0.68, 0],  # cybersecurity engineer
    [0.28, 0.25, 0.33, 0.68, 0.70, 0.68,   0.18, 0.60, 0],  # cloud architect
    [0.15, 0.18, 0.25, 0.85, 0.85, 0.80,   0.35, 0.80, 0],  # llm engineer
    [0.20, 0.22, 0.29, 0.75, 0.72, 0.70,   0.24, 0.70, 0],  # platform engineer
]

# Augment with noise for more robust training
def _augment(rows: List[List], n_copies: int = 8) -> List[List]:
    rng = np.random.default_rng(42)
    augmented = list(rows)
    for row in rows:
        for _ in range(n_copies):
            noise = rng.normal(0, 0.03, len(row) - 1)
            new_row = [
                float(np.clip(row[i] + noise[i], 0.0, 1.0))
                for i in range(len(row) - 1)
            ]
            new_row.append(row[-1])
            augmented.append(new_row)
    return augmented


def build_training_df() -> Tuple[pd.DataFrame, pd.Series]:
    data = _augment(TRAINING_DATA)
    df   = pd.DataFrame(data, columns=FEATURES + ["label"])
    X    = df[FEATURES]
    y    = df["label"].astype(int)
    return X, y


def train_model(track_with_mlflow: bool = True) -> Dict:
    """
    Train XGBoostClassifier, compute eval metrics, optionally log to MLflow.
    Returns dict with model, metrics, and metadata.
    """
    from xgboost import XGBClassifier
    from sklearn.model_selection import cross_val_score, StratifiedKFold
    from sklearn.metrics import classification_report

    logger.info("Training XGBoost risk model...")
    X, y = build_training_df()

    model = XGBClassifier(
        n_estimators      = 200,
        max_depth         = 4,
        learning_rate     = 0.05,
        subsample         = 0.8,
        colsample_bytree  = 0.8,
        use_label_encoder = False,
        eval_metric       = "mlogloss",
        random_state      = 42,
        verbosity         = 0,
    )

    # Cross-validation
    cv     = StratifiedKFold(n_splits=5, shuffle=True, random_state=42)
    cv_acc = cross_val_score(model, X, y, cv=cv, scoring="accuracy")

    # Final fit on all data
    model.fit(X, y)

    # Evaluation on training set (for reference)
    y_pred  = model.predict(X)
    report  = classification_report(y, y_pred, target_names=["Low","Medium","High","Critical"],
                                    output_dict=True)

    metrics = {
        "cv_accuracy_mean": float(cv_acc.mean()),
        "cv_accuracy_std":  float(cv_acc.std()),
        "train_accuracy":   float(report["accuracy"]),
        "f1_low":           float(report["Low"]["f1-score"]),
        "f1_medium":        float(report["Medium"]["f1-score"]),
        "f1_high":          float(report["High"]["f1-score"]),
        "f1_critical":      float(report["Critical"]["f1-score"]),
    }

    meta = {
        "trained_at":      datetime.now(timezone.utc).isoformat(),
        "n_samples":       len(X),
        "n_features":      len(FEATURES),
        "features":        FEATURES,
        "metrics":         metrics,
        "model_version":   "3.0.0",
        "algorithm":       "XGBoostClassifier",
    }

    # Save model + metadata
    MODEL_PATH.parent.mkdir(exist_ok=True)
    with open(MODEL_PATH, "wb") as f:
        pickle.dump(model, f)
    with open(META_PATH, "w") as f:
        json.dump(meta, f, indent=2)

    # MLflow logging (optional)
    if track_with_mlflow:
        try:
            import mlflow
            mlflow.set_experiment("careerai_risk_model")
            with mlflow.start_run(run_name=f"xgb_v{meta['model_version']}"):
                mlflow.log_params({
                    "n_estimators":     200,
                    "max_depth":        4,
                    "learning_rate":    0.05,
                    "n_training_rows":  len(X),
                })
                mlflow.log_metrics(metrics)
                mlflow.sklearn.log_model(model, "risk_model")
            logger.info("Model logged to MLflow")
        except Exception as e:
            logger.warning(f"MLflow logging skipped: {e}")

    logger.info(f"Model trained. CV accuracy: {metrics['cv_accuracy_mean']:.3f} ± {metrics['cv_accuracy_std']:.3f}")
    return {"model": model, "meta": meta, "metrics": metrics}


def load_model():
    """Load model from disk, or train fresh if not found."""
    if MODEL_PATH.exists():
        with open(MODEL_PATH, "rb") as f:
            return pickle.load(f)
    logger.info("No saved model found — training fresh...")
    result = train_model(track_with_mlflow=False)
    return result["model"]


# ── Global model instance (loaded once at startup) ────────────────────────────
_model = None

def get_model():
    global _model
    if _model is None:
        _model = load_model()
    return _model

def reload_model():
    """Called after retraining to hot-swap the in-memory model."""
    global _model
    _model = load_model()
    logger.info("Model hot-reloaded")


def predict_risk(
    routine_task_ratio:   float,
    ai_replaceability:    float,
    sector_automation:    float,
    n_skills:             int   = 10,
    education_level:      float = 0.5,
    experience_years:     float = 3.0,
    demand_growth:        float = 0.05,
    remote_work_ratio:    float = 0.30,
) -> Dict:
    """
    Run XGBoost prediction + SHAP explanation for a single occupation profile.
    Returns risk_score (0-100), risk_category, viability_index, and SHAP values.
    """
    import shap

    model = get_model()

    feature_values = np.array([[
        float(np.clip(routine_task_ratio,  0, 1)),
        float(np.clip(ai_replaceability,   0, 1)),
        float(np.clip(sector_automation,   0, 1)),
        float(min(1.0, n_skills / 20.0)),
        float(np.clip(education_level,     0, 1)),
        float(min(1.0, experience_years / 20.0)),
        float(np.clip(demand_growth,    -0.5, 0.5)),
        float(np.clip(remote_work_ratio,   0, 1)),
    ]])

    # Prediction
    label       = int(model.predict(feature_values)[0])
    proba       = model.predict_proba(feature_values)[0]
    # Convert label to 0-100 score weighted by probabilities
    risk_score  = round(float(np.dot([12, 37, 62, 88], proba)), 1)

    categories  = ["Low", "Medium", "High", "Critical"]
    category    = categories[label]

    # SHAP explanation
    explainer   = shap.TreeExplainer(model)
    shap_vals   = explainer.shap_values(feature_values)
    # shap_vals shape: (n_samples, n_features, n_classes) for XGBoost multiclass
    sv_arr = np.array(shap_vals)
    if sv_arr.ndim == 3:
        # (1, n_features, n_classes) — pick predicted class
        sv = sv_arr[0, :, label]
    elif sv_arr.ndim == 2:
        sv = sv_arr[0]
    else:
        sv = sv_arr

    shap_dict = {
        name: round(float(val), 3)
        for name, val in zip(FEATURES, sv)
    }

    return {
        "risk_score":       risk_score,
        "risk_category":    category,
        "viability_index":  round(100 - risk_score, 1),
        "probabilities": {
            "Low":      round(float(proba[0]), 3),
            "Medium":   round(float(proba[1]), 3),
            "High":     round(float(proba[2]), 3),
            "Critical": round(float(proba[3]), 3),
        },
        "shap_values": shap_dict,
        "model_version": "3.0.0",
        "algorithm":     "XGBoostClassifier",
    }
