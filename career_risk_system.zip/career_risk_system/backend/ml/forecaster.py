import json
import logging
import pickle
from datetime import datetime, timezone, timedelta
from pathlib import Path
from typing import Dict, List, Optional

try:
    import numpy as np
    import pandas as pd
    HAS_NUMPY = True
except ImportError:
    HAS_NUMPY = False

logger = logging.getLogger(__name__)

FORECAST_DIR = Path(__file__).parent.parent / "models" / "forecasts"
FORECAST_DIR.mkdir(parents=True, exist_ok=True)

# Fallback YoY growth rates per role (used when Prophet has <14 data points)
FALLBACK_GROWTH = {
    "data analyst":         0.05,
    "data engineer":        0.20,
    "ml engineer":          0.28,
    "software engineer":    0.03,
    "devops engineer":      0.22,
    "product manager":      0.10,
    "data entry specialist":-0.18,
    "qa tester":           -0.10,
}


def _prophet_model_path(role: str) -> Path:
    safe = role.lower().replace(" ", "_").replace("/", "_")
    return FORECAST_DIR / f"{safe}_prophet.pkl"


def train_prophet(role: str, history: List[Dict]) -> Optional[object]:
    """
    Train a Prophet model on job trend history for a role.
    history: list of {"date": "YYYY-MM-DD", "posting_count": int}
    Returns fitted Prophet model or None if insufficient data.
    """
    if len(history) < 14:
        logger.info(f"Not enough data for Prophet ({len(history)} points) — need ≥14")
        return None

    try:
        from prophet import Prophet
    except ImportError:
        logger.warning("Prophet not installed")
        return None

    df = pd.DataFrame(history).rename(columns={"date": "ds", "posting_count": "y"})
    df["ds"] = pd.to_datetime(df["ds"])
    df = df.sort_values("ds").dropna()

    if len(df) < 14:
        return None

    model = Prophet(
        yearly_seasonality  = True,
        weekly_seasonality  = False,
        daily_seasonality   = False,
        changepoint_prior_scale = 0.05,
        seasonality_prior_scale = 10.0,
        interval_width      = 0.80,
    )
    model.fit(df)

    # Save to disk
    path = _prophet_model_path(role)
    with open(path, "wb") as f:
        pickle.dump(model, f)
    logger.info(f"Prophet model trained and saved for '{role}'")
    return model


def load_prophet(role: str) -> Optional[object]:
    path = _prophet_model_path(role)
    if not path.exists():
        return None
    try:
        with open(path, "rb") as f:
            return pickle.load(f)
    except Exception as e:
        logger.warning(f"Failed to load Prophet model for '{role}': {e}")
        return None


def forecast_with_prophet(
    role:    str,
    history: List[Dict],
    horizon: int = 5,
    current_salary: float = 10.0,
) -> Dict:
    """
    Generate a 5-year forecast using Prophet if possible,
    falling back to simple growth-rate projection.
    """
    model = load_prophet(role) or train_prophet(role, history)

    if model is not None:
        return _prophet_forecast(model, role, horizon, current_salary, history)
    else:
        return _growth_forecast(role, horizon, current_salary, history)


def _prophet_forecast(model, role, horizon, current_salary, history) -> Dict:
    """Run Prophet forecast and format as CareerAI response."""
    future = model.make_future_dataframe(periods=horizon * 365, freq="D")
    fc     = model.predict(future)

    # Extract year-end predictions
    base_year = datetime.now(timezone.utc).year
    yearly    = []
    for i in range(horizon):
        yr  = base_year + i + 1
        yr_rows = fc[fc["ds"].dt.year == yr]
        if yr_rows.empty:
            continue
        last = yr_rows.iloc[-1]
        yearly.append({
            "year":             yr,
            "postings_index":   max(0, int(last["yhat"])),
            "salary_lpa":       round(current_salary * (1 + 0.07) ** (i + 1), 2),
            "confidence_low":   max(0, int(last["yhat_lower"])),
            "confidence_high":  max(0, int(last["yhat_upper"])),
            "method":           "prophet",
        })

    # Compute YoY from forecast
    cur_count = history[0]["posting_count"] if history else 5000
    yoy = (yearly[0]["postings_index"] - cur_count) / max(1, cur_count) if yearly else 0.05

    return {
        "role":                role.title(),
        "current_postings":    cur_count,
        "current_salary_lpa":  current_salary,
        "yoy_growth":          round(yoy, 3),
        "trend_signal":        "rising" if yoy > 0.02 else "declining" if yoy < -0.02 else "stable",
        "forecast":            yearly,
        "history_points":      len(history),
        "forecast_method":     "prophet",
        "fetched_at":          datetime.now(timezone.utc).isoformat(),
    }


def _growth_forecast(role, horizon, current_salary, history) -> Dict:
    """Simple growth-rate projection (Phase 2 fallback)."""
    fb   = FALLBACK_GROWTH
    if len(history) >= 7:
        old, new = history[-1]["posting_count"], history[0]["posting_count"]
        yoy = round((new - old) / old, 3) if old else fb.get(role.lower(), 0.05)
    else:
        yoy = fb.get(role.lower(), 0.05)

    cur_c = history[0]["posting_count"] if history else 5000
    trend = "rising" if yoy > 0.02 else "declining" if yoy < -0.02 else "stable"

    return {
        "role":                role.title(),
        "current_postings":    cur_c,
        "current_salary_lpa":  current_salary,
        "yoy_growth":          yoy,
        "trend_signal":        trend,
        "forecast": [
            {
                "year":             datetime.now(timezone.utc).year + i + 1,
                "postings_index":   round(cur_c * ((1 + yoy) ** (i + 1))),
                "salary_lpa":       round(current_salary * ((1 + yoy * 0.7) ** (i + 1)), 2),
                "confidence_low":   round(cur_c * 0.88 * ((1 + yoy) ** (i + 1))),
                "confidence_high":  round(cur_c * 1.12 * ((1 + yoy) ** (i + 1))),
                "method":           "growth_rate",
            }
            for i in range(horizon)
        ],
        "history_points":  len(history),
        "forecast_method": "growth_rate",
        "fetched_at":      datetime.now(timezone.utc).isoformat(),
    }
