"""
setup.py — Run this ONE file in VS Code terminal to create
the entire project structure automatically.

Usage:
  python setup.py
"""
import os, sys, subprocess

ROOT = os.path.dirname(os.path.abspath(__file__))

FOLDERS = [
    "backend/data",
    "backend/ml",
    "backend/models",
    "backend/nlp",
    "backend/routes",
    "backend/migrations",
    "frontend/src",
    "tests",
]

INIT_FILES = [
    "backend/__init__.py",
    "backend/data/__init__.py",
    "backend/ml/__init__.py",
    "backend/models/__init__.py",
    "backend/nlp/__init__.py",
    "backend/routes/__init__.py",
    "tests/__init__.py",
]

def create_structure():
    print("Creating folder structure...")
    for folder in FOLDERS:
        path = os.path.join(ROOT, folder)
        os.makedirs(path, exist_ok=True)
        print(f"  ✓ {folder}/")

    print("\nCreating __init__.py files...")
    for f in INIT_FILES:
        path = os.path.join(ROOT, f)
        if not os.path.exists(path):
            open(path, "w").close()
            print(f"  ✓ {f}")

    print("\nCopying .env.example to .env...")
    env_example = os.path.join(ROOT, ".env.example")
    env_file    = os.path.join(ROOT, ".env")
    if os.path.exists(env_example) and not os.path.exists(env_file):
        import shutil
        shutil.copy(env_example, env_file)
        print("  ✓ .env created — fill in your free API keys")
    else:
        print("  ✓ .env already exists")

    print("\nDone! Now run:\n")
    print("  1.  python -m venv venv")
    print("  2.  venv\\Scripts\\activate         (Windows)")
    print("      source venv/bin/activate        (Mac/Linux)")
    print("  3.  pip install -r requirements.txt")
    print("  4.  python -m spacy download en_core_web_lg")
    print("  5.  cd backend && uvicorn main:app --reload --port 8000")
    print("  6.  Open frontend/index.html in browser\n")
    print("  API docs: http://localhost:8000/docs")

if __name__ == "__main__":
    create_structure()
