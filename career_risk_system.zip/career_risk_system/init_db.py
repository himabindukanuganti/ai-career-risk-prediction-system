from database import get_connection

with open("backend/sql/schema_sqlite.sql", "r", encoding="utf-8") as f:
    schema = f.read()

conn = get_connection()
cursor = conn.cursor()

cursor.executescript(schema)

conn.commit()
conn.close()

print("SQLite schema loaded successfully!")